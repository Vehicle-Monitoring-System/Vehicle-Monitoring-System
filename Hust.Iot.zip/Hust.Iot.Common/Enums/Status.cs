﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hust.Iot.Common
{
    public enum Status
    {
        Active = 1,
        Stop = 2,
        Parking = 3,
    }
}
